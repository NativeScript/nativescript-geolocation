﻿import "./bundle-config";
import * as application from 'tns-core-modules/application';
application.start({ moduleName: "main-page" });
