require("./vendor-platform");

require("bundle-entry-points");
